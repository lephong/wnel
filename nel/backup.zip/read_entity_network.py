import sys
from nel.vocabulary import Vocabulary

wiki_prefix = 'en.wikipedia.org/wiki/'


def read_ent2id(ent_dic_path, ent2id_path):
    print('load ent dic from', ent_dic_path)
    ent_dic = Vocabulary.load(ent_dic_path)
    ent2id = ent_dic.word2id

    print('load ent2id from', ent2id_path, 'and merge with dic')
    with open(ent2id_path, 'r') as f:
        count = 0
        new_id = len(ent2id)
        print(new_id)

        for line in f:
            e, i = line.strip().split('\t')
            e = wiki_prefix + e.replace(' ', '_').replace('"', '%22')
            if e not in ent2id:
                ent2id[e] = new_id
                new_id += 1

            count += 1
            if count % 1000 == 0:
                print(count, end='\r')

    print(new_id)
    return ent2id


def read_ent_net(net_path, ent2id):
    network = {}
    with open(net_path, 'r') as f:
        count = 0
        for line in f:
            comps = line.strip().split('\t')
            if len(comps) <= 1:
                # print('sthing wrong with', comps)
                continue

            doc = [ent2id.get(wiki_prefix + e.replace(' ', '_').replace('"', '%22'), -1) for e in comps[1:]]
            try:
                title = wiki_prefix + comps[1].split('title=')[-1][1:-2].replace(' ', '_').replace('"', '%22')
                title = ent2id.get(title, -1)
            except:
                print(comps)
                print(comps[1].split('title='))

            doc.append(title)
            doc = set(doc)
            if -1 in doc:
                doc.remove(-1)

            for e in doc:
                if e not in network:
                    network[e] = set()
                network[e] |= doc

            count += 1
            if count % 1000 == 0:
                print(count, end='\r')
            # if count > 10000:
            #     break

    return network


def save(network, path):
    with open(path, 'wb') as f:
        for e, d in network.items():
            f.write(str(e) + ' : ' + ' '.join([str(i) for i in d]) + '\n')


if __name__ == '__main__':
    if len(sys.argv) != 5:
        print('USE: python3 -u read_entity_network.py ../modified_deep_ed/data/basic_data/wiki_entity_net.txt ../data/generated/embeddings/large_word_ent_embs/dict.entity ../modified_deep_ed/data/basic_data/wiki_name_id_map.txt /tmp/x')
        return

    net_path = sys.argv[1]
    ent_dic_path = sys.argv[2]
    ent2id_path = sys.argv[3]
    out_path = sys.argv[4]

    print('------ load ent2id ---------')
    ent2id = read_ent2id(ent_dic_path, ent2id_path)

    print('load net from', net_path)
    network = read_ent_net(net_path, ent2id)
    print('print to file', out_path)
    print_to_file(network, ent2id, out_path)
    print('done')

